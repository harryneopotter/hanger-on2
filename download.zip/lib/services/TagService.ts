export class TagService {
  constructor() {}

  async getAllTags(): Promise<any[]> {
    return [];
  }
}