export class ImageService {
  constructor() {}

  async uploadImage(imageFile: any): Promise<string> {
    return ""; // Placeholder
  }
}